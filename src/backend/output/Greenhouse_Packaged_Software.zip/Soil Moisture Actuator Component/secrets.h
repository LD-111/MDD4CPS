// WiFi credentials
#define SECRET_SSID "your_SSID"      // Replace with your WiFi SSID
#define SECRET_PASS "your_PASSWORD"  // Replace with your WiFi password

// MQTT server settings
#define SECRET_MQTT_BROKER "broker.hivemq.com"  // Example public MQTT broker
#define SECRET_MQTT_PORT 1883                  // Standard MQTT port
